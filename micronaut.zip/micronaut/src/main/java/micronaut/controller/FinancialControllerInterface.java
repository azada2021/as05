package micronaut.controller;

import java.io.IOException;

public interface FinancialControllerInterface {
    Object getFinancialData(String financial_data_provider, String stock_index) throws IOException;
}
