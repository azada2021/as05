package micronaut.controller.impl;

import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import micronaut.controller.FinancialControllerInterface;
import micronaut.service.impl.FinancialServiceImpl;

import javax.inject.Inject;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller("/finance")
public class FinancialControllerImpl implements FinancialControllerInterface {

    @Inject
    private FinancialServiceImpl financialServiceImpl;

    protected static final Logger myLogger = LoggerFactory.getLogger(FinancialControllerImpl.class);

    @Get(produces = MediaType.APPLICATION_JSON)
    public String getFinancialData(@QueryValue("provider") String provider,
                                   @QueryValue("stock_index") String stockIndex) throws IOException {

        myLogger.info(provider);
        myLogger.info(stockIndex);

        return financialServiceImpl.getFinancialData(provider,stockIndex);
    }
}
