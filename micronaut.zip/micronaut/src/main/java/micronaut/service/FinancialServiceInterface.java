package micronaut.service;

import java.io.IOException;

public interface FinancialServiceInterface {
    Object getFinancialData(String provider, String stockIndex) throws IOException;
}
