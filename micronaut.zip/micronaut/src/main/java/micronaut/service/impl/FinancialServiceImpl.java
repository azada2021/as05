package micronaut.service.impl;

import micronaut.service.FinancialServiceInterface;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

import javax.inject.Singleton;
import java.io.IOException;
import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Singleton
public class FinancialServiceImpl implements FinancialServiceInterface {


    protected static final Logger myLogger = LoggerFactory.getLogger(FinancialServiceImpl.class);


    public String getFinancialData(String provider, String stockIndex) throws IOException {
        if (provider.equals("yahoo")) {

            myLogger.info(stockIndex);
            Stock stockName = YahooFinance.get(stockIndex);
            BigDecimal stockPrice = stockName.getQuote().getPrice();

          return stockPrice.toString();
        } else return "Not Found";
    }
}
